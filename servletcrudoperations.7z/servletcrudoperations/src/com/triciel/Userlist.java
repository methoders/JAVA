package com.triciel;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Userlist extends HttpServlet {
	 
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	 @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		// TODO Auto-generated method stub
			PrintWriter pw=resp.getWriter();
			String query="select * from user";
			Connection con=null;
			Statement st=null;
			ResultSet rs=null;
		
			
			   try{  
		            Class.forName("com.mysql.jdbc.Driver");  
		            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  
		           st= con.createStatement();
		           
		           rs=st.executeQuery(query);
		           List<User> list=new ArrayList<User>();
		           
			         
			          
			        /* pw.println("<a href='index.html'>Add New User</a>");
			         pw.println("<h1>Users List</h1>");
			          pw.print("<table border='1' width='100%'");
			          pw.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Edit</th><th>Save</th><th>Delete</th></tr>");  */
			         while(rs.next()){  
			        	  User user=new User();
			        	  user.setId(rs.getInt(1));
			        	  user.setName(rs.getString(2));
			        	  user.setPassword(rs.getInt(3));
			        	  user.setEmail(rs.getString(4));
			        	  list.add(user);
			        	  
			         /* pw.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getInt(3)+"</td><td>"+rs.getString(4)+"</td> <td><input type='button' id='edit_button"+rs.getInt(1)+"' value='Edit' class='edit' onclick='edit_row("+rs.getInt(1)+")'><input type='button' id='save_button"+rs.getInt(1)+"' value='Save' class='save' onclick='save_row("+rs.getInt(1)+")'></td> <td><a href='Deleteuser?id="+rs.getInt(1)+"'>delete</a></td></tr>");  */
			         }  
			      /*
	*/                    req.setAttribute("users", list);
	RequestDispatcher view = req.getRequestDispatcher("result.jsp");
	view.forward(req, resp); 
		        /* pw.println("<a href='index.html'>Add New User</a>");
		         pw.println("<h1>Users List</h1>");
		          pw.print("<table border='1' width='100%'");
		          pw.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Edit</th><th>Save</th><th>Delete</th></tr>");  */
		         while(rs.next()){  
		         /* pw.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getInt(3)+"</td><td>"+rs.getString(4)+"</td> <td><input type='button' id='edit_button"+rs.getInt(1)+"' value='Edit' class='edit' onclick='edit_row("+rs.getInt(1)+")'><input type='button' id='save_button"+rs.getInt(1)+"' value='Save' class='save' onclick='save_row("+rs.getInt(1)+")'></td> <td><a href='Deleteuser?id="+rs.getInt(1)+"'>delete</a></td></tr>");  */
		         }  
		      /*   pw.print("</table>");   */ 
		         
		            
		        }catch(Exception e){System.out.println(e);}  
			
		}
		 
	

}
