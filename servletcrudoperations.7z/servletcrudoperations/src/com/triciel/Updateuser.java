package com.triciel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Updateuser extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=resp.getWriter();
		String query="update user set name=?,password=?,email=? where id=?";
		Connection con=null;
		PreparedStatement st=null;
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		int password=Integer.parseInt(req.getParameter("password"));
		
		String email=req.getParameter("email");
		//pw.println(email+ " "+password+" "+name);
		
		   try{  
	            Class.forName("com.mysql.jdbc.Driver");  
	            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  
	           st= con.prepareStatement(query);
	           
	           st.setString(1, name);
	           st.setInt(2, password);
	           st.setString(3, email);
	           st.setInt(4, id);
	           int res= st.executeUpdate();
	           if(res>0){  
	               pw.print("<p>Record updated successfully!</p>");  
	               req.getRequestDispatcher("index.html").include(req, resp);  
	           }else{  
	               pw.println("Sorry! unable to update record");  
	           }  
	             
	            
	        }catch(Exception e){System.out.println(e);}  
		

	}

}
