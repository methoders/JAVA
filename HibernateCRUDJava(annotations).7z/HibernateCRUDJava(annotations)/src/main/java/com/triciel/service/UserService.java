package com.triciel.service;

import java.util.List;

import com.triciel.dao.UserDao;
import com.triciel.model.User;

public class UserService {

	private UserDao userDao;
	
	//Create of CRUD
	 public void addUser(User user) {
		 userDao.addUser(user);
		 }
	 
	 //Read of CRUD
	public List<User> getAllUsers() {
		return userDao.getAllUsers();
	}

	//Read of CRUD
	    public User getUserById(int userid) {
	    	return userDao.getUserById(userid);
	    }
	    
	  //Update of CRUD
	    public void updateUser(User user) {
	    	userDao.updateUser(user);
	    }

	    //Delete of CRUD
	    public void deleteUser(int userid) {
	    	userDao.deleteUser(userid);
	    }

		public UserDao getUserDao() {
			return userDao;
		}

		public void setUserDao(UserDao userDao) {
			this.userDao = userDao;
		}
}
